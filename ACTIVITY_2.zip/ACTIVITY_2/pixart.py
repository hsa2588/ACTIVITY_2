#First student: Haneen Alrimawi 
#Second student: Yergeshbay Yerkebulan
#Third student: Ahmad Hassan 
#Github link: https://github.com/hsa2588/Activity_2.git





from turtle import Screen, Turtle
t = Turtle()
PIXEL_SIZE = 30
ROWS = 20
COLUMNS = 20
DEFAULT_PEN_COLOR = 'black'
DEFAULT_PIXEL_COLOR = 'white'

def initialization(turta):
    '''Function which sets the speed, pencolor and the starting point of the turtle to start drawing'''
    turta.speed(0)
    turta.penup()
    turta.goto(-PIXEL_SIZE * COLUMNS / 2, PIXEL_SIZE * ROWS / 2) # initial coordinate of the turtle to begin drawing
    turta.setheading(0)
    turta.pendown()
    turta.pencolor(DEFAULT_PEN_COLOR)
    turta.fillcolor(DEFAULT_PIXEL_COLOR)

def get_color(color):

    '''Converts a single character code into the corresponding color name for drawing'''

    if color == '0': 
        return 'black'
    elif color == '1':
        return 'white'
    elif color == '2':
        return 'red'
    elif color == '3':
        return 'yellow'
    elif color == '4':
        return 'orange'
    elif color == '5':
        return 'green'
    elif color == '6':
        return 'yellowgreen'
    elif color == '7':
        return 'sienna'
    elif color == '8':
        return 'tan'
    elif color == '9':
        return 'gray'
    elif color == 'A':
        return 'darkgray'
    else:
        return False

def draw_color_pixel(pixel_color_string, turta):

    """draws a single pixel with the specified color"""

    turta.fillcolor(pixel_color_string)
    turta.begin_fill()
    for _ in range(4):
        turta.forward(PIXEL_SIZE)
        turta.right(90)  
    turta.end_fill()
    
    turta.forward(PIXEL_SIZE)

    
def draw_pixel(pixel_color, turta):
    '''Gets the color string & then draws a pixel using that color'''
    pixel_color_string = get_color(pixel_color)
    draw_color_pixel(pixel_color_string, turta)
    

def draw_line_from_string(color_string, turta):
    """draws a line of pixels based on a string of the chosen color codes"""

    for pixel_color in color_string:
        draw_pixel(pixel_color, turta)
    turta.penup()
    turta.forward(-PIXEL_SIZE*len(color_string))
    turta.right(90)
    turta.forward(PIXEL_SIZE)
    turta.left(90)
    turta.pendown()

def draw_shape_from_string(turta):
    """prompts the user for the string color codes and then draws the shape of it"""

    for _ in range(ROWS):
        color_string = str(input('code - '))
        draw_line_from_string(color_string.strip(), turta)
        


def draw_grid(turta):
    """draws a grid using predefined color patterns"""

    for _ in range(10):
        draw_line_from_string("02020202020202020202", turta)
        draw_line_from_string("20202020202020202020", turta)


def draw_picture_from_file(turta):
    """prompts the user for inputing the path of the file and draws the picture from the file's content"""

    name_file = input("Enter the path of the file that you want to read its content: ")
    with open(name_file, "r") as file:
        for line in file:
            draw_line_from_string(line.strip(), turta)


