from pixart import initialization, draw_picture_from_file
from turtle import Turtle, Screen

def main():
    '''Main function to initialize the turtle and start drawing from a file'''
    screen = Screen()
    turta = Turtle()
    initialization(turta)
    draw_picture_from_file(turta)
    screen.exitonclick()

'''Main function to initialize the turtle and start drawing from the file'''

if __name__ == "__main__":
    main()
